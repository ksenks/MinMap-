//
//  TagViewController.h
//  MinMap
//
//  Created by Lori Hill on 3/22/14.
//  Copyright (c) 2014 Lori Hill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TagViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextView *textView;

@end
